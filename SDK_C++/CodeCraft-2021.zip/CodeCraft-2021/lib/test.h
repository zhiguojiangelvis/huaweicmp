using namespace std;
void hello(){
       cout<<"hello, CodeCraft-2021\n";
}
